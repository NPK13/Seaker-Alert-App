from django.db import models

# Create your models here.
class MetricSample(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    cpu_percent = models.FloatField()
    ram_used_gb = models.FloatField()
    ram_total_gb = models.FloatField()
    disk_used_gb = models.FloatField()
    disk_total_gb = models.FloatField()
    uptime_hours = models.FloatField()
    temperature_c = models.FloatField(null=True, blank=True)

    def __str__(self):
        return f"Sample at {self.created_at:%Y-%m-%d %H:%M:%S}"


class Threshold(models.Model):
    metric = models.CharField(max_length=50)  # e.g. "cpu", "ram"
    limit = models.FloatField()

    def __str__(self):
        return f"{self.metric} > {self.limit}"


class AlertEvent(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    metric = models.CharField(max_length=50)
    value = models.FloatField()
    message = models.TextField()

    def __str__(self):
        return f"[{self.created_at:%Y-%m-%d %H:%M}] {self.message}"
    