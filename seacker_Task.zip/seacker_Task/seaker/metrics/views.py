from django.shortcuts import render
from rest_framework.generics import ListAPIView
from .models import MetricSample, AlertEvent
from .serializers import MetricSampleSerializer, AlertEventSerializer

# API endpoint: latest metrics (last 20 samples)
class LatestMetricAPIView(ListAPIView):
    queryset = MetricSample.objects.order_by("-created_at")[:20]
    serializer_class = MetricSampleSerializer

# API endpoint: alerts (last 10 alerts)
class AlertListAPIView(ListAPIView):
    queryset = AlertEvent.objects.order_by("-created_at")[:10]
    serializer_class = AlertEventSerializer

# Dashboard HTML page
def dashboard(request):
    return render(request, "metrics/dashboard.html")
