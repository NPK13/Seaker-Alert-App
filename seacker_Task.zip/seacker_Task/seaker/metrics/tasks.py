import psutil, datetime
from celery import shared_task
from .models import MetricSample

@shared_task
def collect_metrics():
    cpu = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    uptime = datetime.datetime.now() - datetime.datetime.fromtimestamp(psutil.boot_time())
    uptime_hours = uptime.total_seconds() / 3600

    # Temperature (optional, may not work on Windows)
    try:
        temps = psutil.sensors_temperatures()
        temp = list(temps.values())[0][0].current if temps else None
    except Exception:
        temp = None

    MetricSample.objects.create(
        cpu_percent=cpu,
        ram_used_gb=ram.used / (1024**3),
        ram_total_gb=ram.total / (1024**3),
        disk_used_gb=disk.used / (1024**3),
        disk_total_gb=disk.total / (1024**3),
        uptime_hours=uptime_hours,
        temperature_c=temp,
    )
