from django.urls import path
from .views import LatestMetricAPIView, AlertListAPIView, dashboard

urlpatterns = [
    path("dashboard/", dashboard, name="dashboard"),
    path("metrics/", LatestMetricAPIView.as_view(), name="metrics-api"),
    path("alerts/", AlertListAPIView.as_view(), name="alerts-api"),
]
