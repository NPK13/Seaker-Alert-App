import os
from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "seaker.settings")

app = Celery("seaker")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()
